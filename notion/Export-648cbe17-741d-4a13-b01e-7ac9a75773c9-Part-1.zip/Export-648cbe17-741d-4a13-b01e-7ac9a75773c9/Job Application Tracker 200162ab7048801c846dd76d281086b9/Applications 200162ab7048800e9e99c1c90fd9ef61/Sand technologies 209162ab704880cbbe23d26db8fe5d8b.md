# Sand technologies

Position: global business services intern
Link: https://www.notion.so/Sandtech-global-business-services-intern-Assignment-continuation-209162ab704880f8aecbc7d67853bcac?pvs=55
Stage: Applied

# Action items

- [ ]  

# Notes on the company

- 

# Where can I add value?

- 

# What am I excited about? What will I learn?

- 

# Notes on recruiter/hiring manager

-