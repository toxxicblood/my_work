# Idea hub

- AI trading
    - Instead of building an ai agent from scratch, I can just finetune a model or build an n8n workflow for an agent that takes data as follows.
        - Feed it yesterday's H4 and H1 data.
        - Feed it daily closes from the past few days
        - Feed it today's open.
        - Current positions if any.
        - Ask for feedbakc