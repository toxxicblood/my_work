# Parallelization

This is running multiple LLM calls at the same time