# Programs and opportunities

Created: June 2, 2025 12:03 PM

[Llama impact accelerator: Kenya](Programs%20and%20opportunities%20206162ab704880c0b9fdd6ce0f0fbf6b/Llama%20impact%20accelerator%20Kenya%20207162ab7048805ca95cc75234f7c43e.md)

[African AI opportunities](Programs%20and%20opportunities%20206162ab704880c0b9fdd6ce0f0fbf6b/African%20AI%20opportunities%20206162ab704880a591d4e6a7191d2f9c.md)