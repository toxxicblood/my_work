# Networking & Partnerships

Created: May 31, 2025 2:52 PM

Key People and Organizations in AI Infrastructure

| **Industry** | **Company** | **Contact Person** | **Contact  Name** | **Contact method** | **Status** | **Feedback** | **Next Steps** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Cloud Computing | Microsoft Azure | Africa Team Lead |  |  | Not Reached | - | Schedule initial meeting |
| Data Centers | Africa Data Centres | Regional Director |  |  | Not Reached | - | Connect via LinkedIn |
| AI Research | Google AI | Research Lead |  |  | Not Reached | - | Attend next AI summit |
| Telecom | Safaricom | Innovation Head |  |  | Not Reached | - | Pitch compute proposal |
| Education | ALX Africa | Tech Director |  |  | Not Reached | - | Propose partnership |
| Government | Ministry of ICT | Digital Economy Director |  |  | Not Reached | - | Submit proposal |
| Infrastructure | iColo | CEO |  |  | Not Reached | - | Request meeting |
| Edtech Thought leader | Kytabu, Tribbe, Nailab | CEO | tonee ndungu | email: tonee@toneendungu.com | Not reached | - |  |
| Infrastructure and energy | African Union | Senior digital poicy expert | Souhila Amazouz | email:[SouhilaA@africa-union.org](mailto:SouhilaA@africa-union.org) | Not reached | - | Send an email explaining what im working on |
| Policy maker | Policy center for the new south | Economist, Researcher:macroeconomics | Fahd Azaroual | email: contact@policycenter.ma | Not reached | - | Send an email on his research into Ai global and african opportunities. |
|  | Google kenya | Head of research | Dr Aisha Walcott Bryant |  |  |  |  |

Note: Update status and feedback as you make contact with each person/organization.

## Find contact

- [ ]  Nvidia
- [ ]  google
- [ ]  microsoft
- [ ]  aws
- [ ]  huawei
- [ ]  deep learining indaba
- [ ]  zingi
- [ ]  data science for africa
- [ ]  ministry of ict
- [ ]  konza tech city
- [ ]  kebs
- [ ]  Safaricom
- [ ]  Kenya power
- [ ]  Deepmind
- [ ]  Ujuzikilimo
- [ ]  Mpesa AI
- [ ]  Masakhane
- [ ]  Zindi
- [ ]  Farmdrive
- [ ]