# Llama impact accelerator: Kenya

This program is for startups using open-source AI to  solve real-world challenges in Kenya.

THis program is designed to support early-stage innovation aligned with national development priorities.

- Solutions include:
    
    Healthcare
    
    Education & employment
    
    Agriculture
    
    Public services 
    
    Wild card : exeptional solutions outside main focus
    

this program includes :

- 6 weeks  hands on training
- technical mentorship
- development support

THe climax of the program is a demo day where selected startups pitch for a chace to receive $25000 in equity-free funding

After demo day, participants receive 6 months tailored post-program support to grow their solutions and gain access to other potential funding opportunities at meta.