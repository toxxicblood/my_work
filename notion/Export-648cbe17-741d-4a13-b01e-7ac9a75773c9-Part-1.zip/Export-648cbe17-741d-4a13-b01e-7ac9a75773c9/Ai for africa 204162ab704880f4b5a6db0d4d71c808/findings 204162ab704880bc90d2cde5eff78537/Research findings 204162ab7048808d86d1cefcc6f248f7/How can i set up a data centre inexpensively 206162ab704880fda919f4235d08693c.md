# How can i set up a data centre inexpensively

# Opps

- High hardware costs
- Bad internet
- High energy costs
- Importation, taxes and licensing.
- Experts
-