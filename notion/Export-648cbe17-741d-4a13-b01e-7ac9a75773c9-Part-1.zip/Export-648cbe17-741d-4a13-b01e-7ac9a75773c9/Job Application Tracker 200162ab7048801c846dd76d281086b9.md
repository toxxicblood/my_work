# Job Application Tracker

## Positions to apply to

[Applications](Job%20Application%20Tracker%20200162ab7048801c846dd76d281086b9/Applications%20200162ab7048800e9e99c1c90fd9ef61.csv)

## Action items

Outline and prioritize tasks for your job search journey.

---

- [ ]  Update LinkedIn profile
- [ ]  Finish the sand assignment

## Resume

[Ramsey Njire Resume.pdf](Job%20Application%20Tracker%20200162ab7048801c846dd76d281086b9/Ramsey_Njire_Resume.pdf)

[Sandtech global business services intern Assignment(continuation)](Job%20Application%20Tracker%20200162ab7048801c846dd76d281086b9/Sandtech%20global%20business%20services%20intern%20Assignmen%20209162ab704880f8aecbc7d67853bcac.md)