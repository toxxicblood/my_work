# My Life Planner

[Life segments](My%20Life%20Planner%2020d162ab70488073b243d9cc41a9bb5e/Life%20segments%2020d162ab704880ab9096c34d2b50a6be.csv)