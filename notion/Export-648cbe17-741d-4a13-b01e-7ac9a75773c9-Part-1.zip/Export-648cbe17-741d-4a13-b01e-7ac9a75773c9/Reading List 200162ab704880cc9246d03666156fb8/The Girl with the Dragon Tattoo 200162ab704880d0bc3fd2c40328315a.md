# The Girl with the Dragon Tattoo

Author: Stieg Larsson
Category: Mystery
Status: Not started

## Notes

-