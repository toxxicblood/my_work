# The Diary of a Young Girl

Author: Anne Frank
Category: Biography
Status: Not started

## Notes

-